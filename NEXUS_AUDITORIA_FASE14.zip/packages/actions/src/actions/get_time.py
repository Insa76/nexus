from __future__ import annotations

from datetime import datetime

from actions.base import Action
from planner.execution_context import ExecutionContext
from planner.plan import PlanStep


class GetTimeAction(Action):
    """
    Acción para consultar la hora local del equipo.
    """

    name = "system.get_time"
    description = "Consultar la hora local del sistema."
    internal = True

    produces = ["time"]

    async def execute(
        self,
        context: ExecutionContext,
        step: PlanStep,
    ) -> None:
        current_time = datetime.now().strftime("%H:%M")

        context.add_result("time", current_time)
        context.add_result("status", "read")
