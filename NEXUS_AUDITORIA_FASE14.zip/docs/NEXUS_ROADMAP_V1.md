# NEXUS — ROADMAP V1

## VISIÓN

NEXUS es un asistente cognitivo local y adaptable para personas y organizaciones.

Su objetivo es comprender cómo trabaja una persona o empresa, mantener el contexto de su actividad, recordar información relevante, asistir procesos, ejecutar acciones permitidas, verificar resultados y aprender conocimiento reutilizable para maximizar el tiempo de trabajo.

NEXUS no es:

- solamente una IA local;
- solamente un chatbot;
- solamente un agente de PC;
- solamente un sistema de automatización;
- un producto rígido igual para todas las empresas.

La IA local es una capacidad tecnológica fundamental para permitir que información sensible pueda permanecer dentro de la infraestructura de la organización.

---

# ARQUITECTURA OBJETIVO

```text
                         NEXUS
                           │
              ┌────────────┴────────────┐
              │                         │
       COGNITIVE CORE             ASSISTANT LAYER
              │                         │
        Understand                  User
        Context                     Organization
        Decide                      Projects
        Objective                   Documents
        Plan                        Tasks
        Execute                     Processes
        Verify                      Rules
        Learn                       Preferences
              │                      Policies
              │                         │
              └────────────┬────────────┘
                           │
                         MEMORY
                           │
              ┌────────────┼────────────┐
              │            │            │
           Working      Episodic      Semantic
              │            │            │
              └────────────┼────────────┘
                           │
                        RUNTIME
                           │
              ┌────────────┼────────────┐
              │            │            │
           Tools       Providers      Adapters
              │            │            │
              └────────────┼────────────┘
                           │
                     LOCAL SYSTEM
                           │
                         PRESENCE
                           │
                  Reactive + Proactive


```

## Validaciones funcionales recientes

### Consulta de hora local (system.get_time)

**Estado:** Implementada y validada mediante pruebas unitarias y de integración.

**Fecha de validación:** 15/10/2026.

**Comportamiento validado:**
- Reconocimiento de consultas de hora en español.
- Registro de la hora local en formato HH:MM.
- Generación de una respuesta humana mediante el formateador.
- Ejecución de extremo a extremo a través de nengine.execute(...).

**Resultado de regresión relacionada:** 43 pruebas aprobadas, 3 warnings y 0 fallos.

**Alcance del cierre:** Se considera cerrada la incorporación de system.get_time. Esta validación no implica el cierre global de NEXUS V1.

---

## Incidencias técnicas pendientes

### 1. ResourceWarning en el lanzamiento de aplicaciones

**Estado:** Pendiente de investigación.

**Fecha de registro:** 12/10/2026.

**Comportamiento observado:**
- La suite completa pasa: 898 pruebas aprobadas.
- La prueba `tests/test_core_regression.py::test_open_app` pasa, pero emite `ResourceWarning: subprocess ... is still running`.
- El aviso se reproduce también con `subprocess.Popen` en una prueba aislada.
- Conservar la referencia a `Popen` no eliminó la advertencia.
- La apertura de Notepad funciona correctamente.

**Archivo relacionado:** `packages/adapters/src/adapters/windows/app_launcher.py`.

**Próxima acción:** Investigar la gestión del ciclo de vida de los procesos iniciados por NEXUS, sin bloquear la apertura ni cerrar automáticamente las aplicaciones.

**Criterio de cierre:** Identificar la causa, aplicar una corrección justificada y validar el comportamiento mediante pruebas específicas.

### 2. DeprecationWarning en capturas de pantalla

**Estado:** Pendiente de revisión.

**Archivo:** `packages/adapters/src/adapters/windows/screen_capture.py`.

**Comportamiento observado:** La suite registra tres advertencias porque `mss.mss()` está obsoleto y será eliminado en una versión futura de la biblioteca.

**Próxima acción:** Revisar la API vigente de `mss`, actualizar la llamada y ejecutar las pruebas de captura correspondientes.
